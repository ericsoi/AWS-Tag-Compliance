import boto3, datetime, compliance
from botocore.exceptions import ClientError
from input import *
def instancetag(event, context):
    requiredtags = requiredTags(event, context) #Call function requiredTags from compliant.py as input from user. 
    now = datetime.datetime.now()
    
    class tag:
        def addtag(resourceid):
            now = datetime.datetime.today().strftime('%Y-%m-%d')
            now = datetime.datetime.strptime(now, '%Y-%m-%d')
            stopdate = now + datetime.timedelta(days=0)
            puttag = ec2.create_tags(Resources=[resourceid],Tags=[{'Key': 'Name', 'Value':'not-provided,_power_down_on_' + str(stopdate)}, {'Key':'stop-instance', 'Value':str(stopdate)}])
        def addrequiredtag(resourceid):
            puttag = ec2.create_tags(Resources=[resourceid],Tags=[requiredtags])
    
    ec2 = boto3.client('ec2')
    notags = ec2.describe_instances()
    for instancemetadata in notags["Reservations"]:
        for instance in instancemetadata['Instances']:
            
            #No tags completely
            if not('Tags' in instance):
                tag.addrequiredtag(instance['InstanceId'])
                tag.addtag(instance['InstanceId'])
    
            #Have tags
            else:
                def strtime(time):
                    timeDifference = time - now
                    
                    if timeDifference <= datetime.timedelta():
                        #print(timeDifference)
                        try:
                            ec2.stop_instances(InstanceIds=[instance['InstanceId']])  
                            print("Stopped Instance", instance["InstanceId"])
                        except ClientError as e:
                        	print(e)
                for tags in instance['Tags']:
                    # Instances marked for power down
                    if tags["Key"] == "stop-instance":
                        try:
                            stopTime = datetime.datetime.strptime(tags['Value'], "%Y-%m-%d %H:%M:%S")
                            strtime(stopTime)  
                            
    
                        except ValueError:
                            stopTime = datetime.datetime.strptime(tags['Value'], "%Y-%m-%d-%H:%M:%S")
                            strtime(stopTime) 
                        except :  
                            pass
                if not (requiredtags in instance['Tags']):
                    print(instance["InstanceId"])
                    tag.addrequiredtag(instance['InstanceId'])
                #print(instance['Tags'])
                tag_list = instance['Tags']
                if not list(filter(lambda tag_list: tag_list['Key'] == 'Name', tag_list)):
                    #print(instance['InstanceId'])
                    tag.addtag(instance['InstanceId'])
            
    compliance.comply(event, context)