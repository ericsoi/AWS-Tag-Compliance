import boto3, spaces, compliance
from botocore.exceptions import ClientError

def tolower(event, context):
    ec2 = boto3.client('ec2')
    response = ec2.describe_tags()

    def replaceTags():
        try:
            ec2.delete_tags(Resources=[tags["ResourceId"]], Tags=[{'Key':tags["Key"], 'Value':tags["Value"]}])
            ec2.create_tags(Resources=[tags["ResourceId"]], Tags=[{'Key':newTagKey, 'Value':newTagValue}])
        except ClientError:
            pass

    for tags in response["Tags"]:
        confirmpatchgroup = tags["Key"].lower().replace(' ', '')
        
        if not (tags["Key"] == "Name" or tags["Key"] == "Patch Group" or confirmpatchgroup == 'patchgroup'):
            if (any(x.isupper() for x in tags["Key"]) or any(x.isupper() for x in tags["Value"])):
                
                newTagKey = tags["Key"].lower() 
                newTagValue = tags["Value"].lower()
                replaceTags()     
                    
        else:
            print(tags)
            if tags["Key"] == "Name": 
               ec2.create_tags(Resources=[tags["ResourceId"]], Tags=[{'Key':tags["Key"].lower(), 'Value':tags["Value"].lower()}]) 
            if any(x.isupper() for x in tags["Value"]) and not confirmpatchgroup == 'patchgroup':
                newTagKey = tags["Key"]
                newTagValue = tags["Value"].lower()
                replaceTags()
    print('Done Executing lower.py')
    #Call the other scripts after execution.

    spaces.removespaces(event, context)
    compliance.comply(event, context)