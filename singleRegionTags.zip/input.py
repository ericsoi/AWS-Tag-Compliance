#Define your variables here to be used in the scripts

required_tags           = {"Key":"environment", "Value":"devops"}       #replace with a set of your required tags. 
sns_region              = 'eu-west-3'                                   #replace with Region where your SNS Topic resides
topic_arn               = 'arn:aws:sns:eu-west-3:923903436004:task17'   #replace with your topic arn
output_bucket           = 'enquizit'                                    #Replace with your s3 bucket
allowed_untaged_days    = 0                                             #Replace with desireble number of days to keep untagged instances running















#Passes the above data to name.py
def requiredTags(event, context):
    return required_tags
def SNSRegion(event, context):
    return sns_region
def TOPICArn(event, context):
    return topic_arn
def OUTPUTbucket(event, context):
    return output_bucket
def ALLOWED_untaged_days(event, context):
	return allowed_untaged_days