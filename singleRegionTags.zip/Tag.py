import boto3, lower

#Tag resources that donot have any tag with key "Name", Value "not-provided"
def resources(event, context):
    def tag(resourceid):
        tag = client.create_tags(Resources=[resourceid],Tags=[{'Key': 'Name', 'Value':'not-provided'},])
    
    # Customer gateways
    client = boto3.client('ec2')
    gateway = client.describe_customer_gateways()
    for gateway in gateway['CustomerGateways']:
        if not gateway['Tags']:
            tag(gateway['CustomerGatewayId'])
    
    #Elastic Ips
    eips = client.describe_addresses()
    for adress in eips["Addresses"]:
        if not 'Tags' in adress:
            tag(adress['AllocationId'])
    
    #Instances
    instances = client.describe_instances()
    for instancemetadata in instances["Reservations"]:
        for instance in instancemetadata['Instances']:
            if not('Tags' in instance):
                tag(instance['InstanceId'])
                
    #Images
    
    images = client.describe_images(Owners=['self'])
    for image in images['Images']:
        if not 'Tags' in image:
            tag(image['ImageId'])
    
    #Intanet Gateways        
    internet_gateways = client.describe_internet_gateways()
    for gateway in internet_gateways['InternetGateways']:
        if not gateway['Tags']:
            tag(gateway['InternetGatewayId'])
    
    #Network Acls    
    network_acls = client.describe_network_acls()
    for acl in network_acls['NetworkAcls']:
        if not 'Tags' in acl:
            tag(acl['NetworkAclId'])
    
    #networkInterfaces      
    networkInterfaces = client.describe_network_interfaces()
    for association in(networkInterfaces['NetworkInterfaces']):
        if not(association['TagSet']):
            tag(association['NetworkInterfaceId'])  
    
    #routetables
    routetables = client.describe_route_tables()
    for association in routetables['RouteTables']:
        if not 'Tags' in association:
            tag(association['RouteTableId']) 
    
    #securitygroups
    securitygroups = client.describe_security_groups()
    for sg in securitygroups['SecurityGroups']:
        if not 'Tags' in sg:
            tag(sg['GroupId']) 
    
    #snapshots    
    snapshots = client.describe_snapshots(OwnerIds=['self'])
    for snapshot in snapshots['Snapshots']:
        if not 'Tags' in snapshot:
            tag(snapshot['SnapshotId'])
    
        
    #subnets
    subnets = client.describe_subnets()
    for subnet in subnets['Subnets']:
        if not 'Tags' in subnet:
            tag(subnet['SubnetId'])
    
    #volumes
    volumes = client.describe_volumes()
    for volume in volumes['Volumes']:
        if not 'Tags' in volume:
            tag(volume['VolumeId'])
    
    
    # vpnconnections  
    vpnconnections = client.describe_vpn_connections()
    for vpn in vpnconnections['VpnConnections']:
        if not vpn['Tags']:
            tag(vpn['VpnConnectionId'])
            
    # vpngateways
    vpngateways = client.describe_vpn_gateways()
    for vpn in vpngateways['VpnGateways']:
        if not vpn['Tags']:
            tag(vpn['VpnGatewayId'])
            
    #volumes
    volumes = client.describe_volumes()
    for volume in volumes['Volumes']:
        if not 'Tags' in volume:
            tag(volume['VolumeId'])
    print('Done Executing Tag.py') 
    lower.tolower(event, context)