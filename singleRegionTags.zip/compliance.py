import boto3, json
from input import *
from datetime import datetime 
def comply(event, context):
    Namecompliant = [] # List to hold resource ids with tag Name
    TagCompliant = [] # List to hold tag compliant resource ids
    TagNonCompliant = [] #List to hold non compliant resource ids
    requiredtags = requiredTags(event, context) #Call function requiredTags from compliant.py as input from user. 
    snsRegion = SNSRegion(event, context) #Call function SNSRegion from compliant.py as input from user. 
    topicarn = TOPICArn(event, context) #Call function TOPICArn from compliant.py as input from user. 
    outputbucket = OUTPUTbucket(event, context) #Call function OUTPUTbucket from compliant.py as input from user. 
    s3 = boto3.resource('s3') #connect to s3
    sns = boto3.client('sns', snsRegion)  #connect to sns
    ec2 = boto3.client('ec2') #connect to ec2
    # initialize time as a variable to name output file to s3
    now = '{}:{}:{} {} {} {}'.format(datetime.now().hour, datetime.now().minute, datetime.now().second, datetime.now().day, datetime.now().month, datetime.now().year)
    
    response = ec2.describe_tags()
    for tags in response["Tags"]:
        if tags["Key"] == "Name":
            Namecompliant.append(tags['ResourceId'])
        else:
            if not tags['ResourceId'] in Namecompliant:
                ec2.create_tags(Resources=[tags["ResourceId"]], Tags=[{'Key':'Name', 'Value':'not-provided'}]) 
        if (all(item in tags.items() for item in requiredtags.items())):
            TagCompliant.append(tags["ResourceId"])
        else:
            TagNonCompliant.append(tags["ResourceId"])
    NonCompliant = list(set([item for item in TagNonCompliant if item not in TagCompliant]))

    with open('/tmp/output.json', 'w') as outfile: #create an output file output.json to output the results 
        for i, z in enumerate(NonCompliant): #Count all the resources that are in the TagNonCompliant list

            notification = {"Resource": z}
            json.dump(notification, outfile, sort_keys=True, indent=4)
    data = open('/tmp/output.json', 'rb') #data to be sent to s3
    s3.Bucket(outputbucket).put_object(Key=now + ' output.json', Body=data) #Send data to s3 bucket
    snsMessage = '{} Resources are not compliant to this set of tags {}. Get the full list in your configuration bucket "{}"'.format(str(i), requiredtags, outputbucket) #message to be published to sns topic
    # sending message
    message = sns.publish(
        TopicArn= topicarn,
        Message= snsMessage,
        Subject='Required Tags'
    )
    print('Done Executing compliance.py')
    