import boto3
from botocore.exceptions import ClientError

def removespaces(event, context):
    ec2 = boto3.client('ec2')
    response = ec2.describe_tags()

    def replaceTags():
        try:
            ec2.delete_tags(Resources=[tags["ResourceId"]], Tags=[{'Key':tags["Key"], 'Value':tags["Value"]}])
            ec2.create_tags(Resources=[tags["ResourceId"]], Tags=[{'Key':newTagKey, 'Value':newTagValue}])
        except ClientError:
            pass
    for tags in response["Tags"]:
        if tags["Key"] != "Patch Group":
            confirmpatchgroup = tags["Key"].lower().replace(' ', '')
            if confirmpatchgroup == 'patchgroup':
                newTagKey = confirmpatchgroup.replace('h', 'h ').title()
                newTagValue = tags["Value"].title()
                replaceTags() 
            elif (" " in tags["Key"]) or (" " in tags["Value"]):
                newTagKey = tags["Key"].replace(" ", "-", 1)
                newTagKey = newTagKey.replace(" ", "")
                newTagValue = tags["Value"].replace(" ", "-", 1)
                newTagValue = newTagValue.replace(" ", "")
                replaceTags() 
            
        else:
            newTagKey = tags["Key"]
            newTagValue = tags["Value"].title()
            replaceTags()
    print('Done Executing spaces.py')