import boto3, spaces
def tolower(event, context):
    # replace tags function
    def replace():
        untagResource = client.untag_resources(ResourceARNList=[resource['ResourceARN'],],TagKeys=[tags["Key"],])
        tagResource = client.tag_resources(ResourceARNList=[resource['ResourceARN'],],Tags={newTagKey:newTagValue})
   
    ec2 = boto3.client('ec2')
    client = boto3.client('resourcegroupstaggingapi')
    response = client.get_resources(TagsPerPage=500)
    for resource in response['ResourceTagMappingList']:
        for tags in resource['Tags']:
            if not ((tags["Key"] == "Name") or (tags["Key"] == "Patch Group")): # Skip tag keys Name and Patch Group
                if (any(x.isupper() for x in tags["Key"]) or any(x.isupper() for x in tags["Value"])): #Check for uppercase letter in a tag
                    
                    newTagKey = tags["Key"].lower() # replace tags with lowercase
                    newTagValue = tags["Value"].lower() # replace tags with lowercase
                    replace() # call the replace function
            else:
                if tags["Key"] == "Name":
                    client.tag_resources(ResourceARNList=[resource['ResourceARN'],],Tags={tags["Key"].lower():tags["Value"].lower()})
                if any(x.isupper() for x in tags["Value"]):
                    newTagKey = tags["Key"]
                    newTagValue = tags["Value"].lower()
                    replace() # call the replace function
    print('Done Executing lower.py')
    #Call the other scripts after execution.
    spaces.removespaces(event, context)