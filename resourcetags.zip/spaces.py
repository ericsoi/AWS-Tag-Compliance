import boto3
def removespaces(event, context):
    # replace tags function
    def replace():
        untagResource = client.untag_resources(ResourceARNList=[resource['ResourceARN'],],TagKeys=[tags["Key"],])
        tagResource = client.tag_resources(ResourceARNList=[resource['ResourceARN'],],Tags={newTagKey:newTagValue})
    
    client = boto3.client('resourcegroupstaggingapi')
    response = client.get_resources(TagsPerPage=500)
    for resource in response['ResourceTagMappingList']:
        for tags in resource['Tags']:
            if tags["Key"] != "Patch Group": #Skip tag key Patch Group
                if (" " in tags["Key"]) or (" " in tags["Value"]): #Check for the existence of spaces in a tag
                    # Replace the first instance of the space with an hyphen
                    newTagKey = tags["Key"].replace(" ", "-", 1) 
                    newTagKey = newTagKey.replace(" ", "") 
                    newTagValue = tags["Value"].replace(" ", "-", 1)
                    newTagValue = newTagValue.replace(" ", "")
                    replace()
            else:
                newTagKey = tags["Key"]
                newTagValue = (tags["Value"].replace("-", " ").title())
                replace()
  
    print('Done Executing spaces.py')

    
    