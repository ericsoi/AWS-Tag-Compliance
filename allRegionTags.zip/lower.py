import boto3
def tolower(event, context):
    # replace tags function
    def replace():
        untagResource = client.untag_resources(ResourceARNList=[resource['ResourceARN'],],TagKeys=[tags["Key"],])
        tagResource = client.tag_resources(ResourceARNList=[resource['ResourceARN'],],Tags={newTagKey:newTagValue})
    ec2 = boto3.client('ec2') 
    response = ec2.describe_regions()
    for region in response['Regions']:
        regionName = region['RegionName']
        ec2 = boto3.client('ec2', regionName)
        client = boto3.client('resourcegroupstaggingapi', region_name=regionName)
        response = client.get_resources(TagsPerPage=500)
        for resource in response['ResourceTagMappingList']:
            for tags in resource['Tags']:
                if not ((tags["Key"] == "Name") or (tags["Key"] == "Patch Group")): # Skip tag keys Name and Patch Group
                    if (any(x.isupper() for x in tags["Key"]) or any(x.isupper() for x in tags["Value"])): #Check for uppercase letter in a tag
                        
                        newTagKey = tags["Key"].lower() # replace tags with lowercase
                        newTagValue = tags["Value"].lower() # replace tags with lowercase
                        replace() # call the replace function
                else:
                    if any(x.isupper() for x in tags["Value"]):
                        newTagKey = tags["Key"]
                        newTagValue = tags["Value"].lower()
                        replace() # call the replace function