import boto3, json
from input import *
from datetime import datetime 
def comply(event, context):
    Namecompliant = [] # List to hold resource ids with tag Name
    TagCompliant = [] # List to hold tag compliant resource ids
    TagNonCompliant = [] #List to hold non compliant resource ids
    requiredtags = requiredTags(event, context) #Call function requiredTags from compliant.py as input from user. 
    snsRegion = SNSRegion(event, context) #Call function SNSRegion from compliant.py as input from user. 
    topicarn = TOPICArn(event, context) #Call function TOPICArn from compliant.py as input from user. 
    outputbucket = OUTPUTbucket(event, context) #Call function OUTPUTbucket from compliant.py as input from user. 
    s3 = boto3.resource('s3') #connect to s3
    sns = boto3.client('sns', snsRegion)  #connect to sns
    ec2 = boto3.client('ec2') #connect to ec2
    response = ec2.describe_regions() # Get Regions
    # initialize time as a variable to name output file to s3
    now = '{}:{}:{} {} {} {}'.format(datetime.now().hour, datetime.now().minute, datetime.now().second, datetime.now().day, datetime.now().month, datetime.now().year)

    for region in response['Regions']:
        regionName = region['RegionName']
        ec2 = boto3.client('ec2', regionName)
        #get resource tags
        client = boto3.client('resourcegroupstaggingapi', region_name=regionName) 
        response = client.get_resources(TagsPerPage=500) #Get the maximum number of tags 
        for resource in response['ResourceTagMappingList']:
            for tags in resource['Tags']:
                if tags["Key"] == "Name":
                    Namecompliant.append(resource['ResourceARN']) #Append resources with tag key Name to Namecompliant list
                if tags['Key'] != 'Name':
                    if not (resource['ResourceARN'] in Namecompliant): 
                        #tag resources without tag key Name with 'not-provided'
                        putTag = client.tag_resources(ResourceARNList=[resource['ResourceARN']], Tags={'Name':'not-provided'})
                if (all(item in tags.items() for item in requiredtags.items())): #Check for required tags in all tags of a resource
                    TagCompliant.append(resource['ResourceARN']) #Append all that comply to TagCompliant list
                if not (all(item in tags.items() for item in requiredtags.items())):
                    if not resource['ResourceARN'] in TagCompliant:
                        TagNonCompliant.append(resource['ResourceARN']) #Append all that are non-compliant to TagNonCompliant list
    #format noncompliant list items to get Resource, ResourceId and Region     
    TagNonCompliant = list(set(TagNonCompliant)) 
    with open('/tmp/output.json', 'w') as outfile: #create an output file output.json to output the results 
        for i, z in enumerate(TagNonCompliant): #Count all the resources that are in the TagNonCompliant list
            resources = z.split(':') 
            ResourctypeResourceid = resources[-1].split("/")
            notification = {"Resource": ResourctypeResourceid[0], "ResourceId":ResourctypeResourceid[-1], "Region":resources[3]}
            json.dump(notification, outfile, sort_keys=True, indent=4)
    data = open('/tmp/output.json', 'rb') #data to be sent to s3
    s3.Bucket(outputbucket).put_object(Key=now + ' output.json', Body=data) #Send data to s3 bucket
    snsMessage = '{} Resources are not compliant to this set of tags {}. Get the full lust in your configuration bucket "{}"'.format(str(i), requiredtags, outputbucket) #message to be published to sns topic
    # sending message
    message = sns.publish(
        TopicArn= topicarn,
        Message= snsMessage,
        Subject='Required Tags'
    )