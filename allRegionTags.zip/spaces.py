import boto3, lower, compliance
def removespaces(event, context):
    # replace tags function
    def replace():
        untagResource = client.untag_resources(ResourceARNList=[resource['ResourceARN'],],TagKeys=[tags["Key"],])
        tagResource = client.tag_resources(ResourceARNList=[resource['ResourceARN'],],Tags={newTagKey:newTagValue})
    ec2 = boto3.client('ec2')
    response = ec2.describe_regions()
    for region in response['Regions']:
        regionName = region['RegionName']
        ec2 = boto3.client('ec2', regionName)
        client = boto3.client('resourcegroupstaggingapi', region_name=regionName)
        response = client.get_resources(TagsPerPage=500)
        for resource in response['ResourceTagMappingList']:
            for tags in resource['Tags']:
                if tags["Key"] != "Patch Group": #Skip tag key Patch Group
                    if (" " in tags["Key"]) or (" " in tags["Value"]): #Check for the existence of spaces in a tag
                        # Replace the first instance of the space with an hyphen
                        newTagKey = tags["Key"].replace(" ", "-", 1) 
                        newTagKey = newTagKey.replace(" ", "") 
                        newTagValue = tags["Value"].replace(" ", "-", 1)
                        newTagValue = newTagValue.replace(" ", "")
                        replace()
                elif (" " in tags["Value"]):
                    newTagKey = tags["Key"]
                    newTagValue = tags["Value"].replace(" ", "-", 1)
                    newTagValue = newTagValue.replace(" ", "")
                    replace()
    #Call the other scripts after execution.
    lower.tolower(event, context) 
    compliance.comply(event, context)
    
    